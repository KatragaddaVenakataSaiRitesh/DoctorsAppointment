//
//  ViewController.swift
//  DoctorsAppointment
//
//  Created by ritesh Chowdary on 3/8/20.
//  Copyright © 2020 Ritesh Chowdary. All rights reserved.
//

import UIKit

class ViewController: UIViewController,UIPickerViewDelegate,UIPickerViewDataSource {
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        return avDoc.count
    }
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        doName = avDoc[row].name
        return avDoc[row].name
    }
    var doName: String? = nil
    @IBOutlet weak var docNames: UIPickerView!
    @IBOutlet weak var morning: UIButton!
    @IBOutlet weak var afternoon: UIButton!
    @IBOutlet weak var eve: UIButton!
    @IBOutlet weak var msg1: UILabel!
    
    @IBOutlet weak var msg: UILabel!
    
    var Dname: [name] = []
     var avDoc: [name]=[]
    
        func findDoc(){
            for x in Dname{
            if x.status{
                avDoc.append(x)
            }
        }
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
       Dname.append(name(name:"Dr.Susan", status:false))
       Dname.append(name(name:"Dr.Jack", status:true))
       Dname.append(name(name:"Dr.Steav", status:true))
       Dname.append(name(name:"Dr.Jessie", status:true))
       Dname.append(name(name:"Dr.Charles", status:true))
       Dname.append(name(name:"Dr.Diana", status:true))
        findDoc()
        self.docNames.delegate = self
        self.docNames.dataSource = self
   }
    
    @IBAction func but1(_ sender: UIButton) {
        if sender.isSelected
        {
            sender.isSelected = false
        }
        else
        {
            afternoon.isSelected = false
            eve.isSelected = false
            sender.isSelected = true
            
        }
    }
    @IBAction func but2(_ sender: UIButton) {
        if sender.isSelected
        {
            sender.isSelected = false
        }
        else
        {
            morning.isSelected = false
            eve.isSelected = false
            sender.isSelected = true
        }
    }
    @IBAction func but3(_ sender: UIButton) {
        if sender.isSelected
        {
            sender.isSelected = false
        }
        else
        {
            afternoon.isSelected = false
            morning.isSelected = false
            sender.isSelected = true
        }
    }
    
    
    @IBAction func book(_ sender: Any) {
        if morning.isSelected {
            msg.text = "Booked appointment between 10 - 12"
        }
        else if afternoon.isSelected{
            msg.text = " Booked appointment between 1 - 4"
        }
        else if eve.isSelected{
            msg.text = "Booked appointment between 5 - 7"
        }
        msg1.text = "Booking successfull.."
    }
    
}

