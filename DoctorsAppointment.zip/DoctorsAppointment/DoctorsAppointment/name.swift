//
//  name.swift
//  DoctorsAppointment
//
//  Created by mukesh Chowdary on 3/8/20.
//  Copyright © 2020 Ritesh Chowdary. All rights reserved.
//

import Foundation
class name{
    var name: String
    var status: Bool
    init(name: String, status: Bool){
        self.name = name
        self.status = status

    }
}
